import React from 'react';

function TestPage() {
    return <div>TestPage</div>;
}

export default TestPage;
